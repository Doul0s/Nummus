import { getLocales } from "expo-localization";

/** Amounts are stored as integer minor units (e.g. cents) to avoid float drift. */
export const MINOR_UNITS_PER_MAJOR = 100;

/** Used when the device locale exposes no currency code (always the case on web). */
export const FALLBACK_CURRENCY_CODE = "EUR";

export type CurrencyCode = string;

export function getDeviceCurrency(): CurrencyCode {
  return getLocales()[0]?.currencyCode ?? FALLBACK_CURRENCY_CODE;
}

export function getDeviceDecimalSeparator(): string {
  return getLocales()[0]?.decimalSeparator ?? ".";
}

/**
 * Renders minor units as a localized currency string.
 * TODO: use Intl.NumberFormat with the locale's decimal/grouping separators,
 * and verify Hermes has full ICU before relying on it.
 */
export function formatMoney(
  minorUnits: number,
  currencyCode: CurrencyCode = getDeviceCurrency()
): string {
  throw new Error(`TODO: implement formatMoney(${minorUnits}, ${currencyCode})`);
}

/**
 * Parses user input into minor units, honouring the locale decimal separator.
 * Returns null when the input is not a valid positive amount.
 */
export function parseAmountToMinorUnits(input: string): number | null {
  throw new Error(`TODO: implement parseAmountToMinorUnits("${input}")`);
}

export function sumMinorUnits(amounts: number[]): number {
  throw new Error(`TODO: implement sumMinorUnits([${amounts.length} items])`);
}