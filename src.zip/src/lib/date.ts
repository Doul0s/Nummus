import { getCalendars } from "expo-localization";

/** Dates are persisted as ISO 8601 calendar dates in the device time zone. */
export type IsoDate = string;

export function getDeviceTimeZone(): string | null {
  return getCalendars()[0]?.timeZone ?? null;
}

export function getDeviceFirstWeekday(): number {
  return getCalendars()[0]?.firstWeekday ?? 1;
}

/** Today's date as YYYY-MM-DD in the device time zone. */
export function todayIso(): IsoDate {
  throw new Error("TODO: implement todayIso()");
}

export function toIsoDate(date: Date): IsoDate {
  throw new Error("TODO: implement toIsoDate(date)");
}

/** Bucket key for grouping expenses by month, e.g. "2026-10". */
export function monthKeyOf(isoDate: IsoDate): string {
  throw new Error(`TODO: implement monthKeyOf("${isoDate}")`);
}

/** Half-open ISO range [startIso, endIso) covering the given month key. */
export function monthRange(monthKey: string): { startIso: IsoDate; endIso: IsoDate } {
  throw new Error(`TODO: implement monthRange("${monthKey}")`);
}

/** Relative label ("Today", "Yesterday") or a localized date, depending on age. */
export function formatDayLabel(isoDate: IsoDate, languageTag: string): string {
  throw new Error(`TODO: implement formatDayLabel("${isoDate}", "${languageTag}")`);
}