import { Link, Stack } from "expo-router";
import { useTranslation } from "react-i18next";
import { StyleSheet, Text, View } from "react-native";

export default function Index() {
  const { t } = useTranslation();

  // TODO: read listExpenses + sumExpensesMinor via useSQLiteContext() on focus,
  // group the rows by monthKeyOf(spentAt), and render one section per month.
  const expenses: never[] = [];

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ title: t("index.title") }} />

      {expenses.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyTitle}>{t("index.empty")}</Text>
          <Text style={styles.emptyHint}>{t("index.emptyHint")}</Text>
        </View>
      ) : (
        <View>
          {/* TODO: FlatList of expenses; each row renders label,
              formatDayLabel(spentAt, i18n.language) and
              formatMoney(amountMinor, currencyCode). */}
        </View>
      )}

      <View style={styles.footer}>
        {/* TODO: render formatMoney(await sumExpensesMinor(db, monthRange(monthKey))). */}
        <Text style={styles.totalLabel}>{t("index.total")}</Text>
      </View>

      <Link href="/add" style={styles.addButton}>
        <Text style={styles.addButtonText}>{t("index.add")}</Text>
      </Link>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    gap: 16,
  },
  empty: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
  },
  emptyTitle: {
    fontSize: 17,
    fontWeight: "600",
  },
  emptyHint: {
    fontSize: 14,
    opacity: 0.6,
    textAlign: "center",
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  totalLabel: {
    fontSize: 15,
    opacity: 0.6,
  },
  addButton: {
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
  },
  addButtonText: {
    fontSize: 16,
    fontWeight: "600",
  },
});