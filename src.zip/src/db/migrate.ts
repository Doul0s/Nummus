import type { SQLiteDatabase } from "expo-sqlite";

export const DATABASE_NAME = "nummus.db";

type Migration = {
  version: number;
  statements: string[];
};

/**
 * Applied in ascending order; only entries with a version greater than
 * PRAGMA user_version are run. Never edit an applied migration, append a new one.
 */
export const migrations: Migration[] = [
  {
    version: 1,
    statements: [
      `CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        amount_minor INTEGER NOT NULL,
        currency_code TEXT NOT NULL,
        label TEXT NOT NULL,
        note TEXT,
        spent_at TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );`,
      `CREATE INDEX IF NOT EXISTS expenses_spent_at_idx ON expenses (spent_at DESC);`,
    ],
  },
];

export const SCHEMA_VERSION = migrations.reduce(
  (highest, migration) => Math.max(highest, migration.version),
  0
);

/** `onInit` handler for <SQLiteProvider>. */
export async function migrateDbIfNeeded(db: SQLiteDatabase): Promise<void> {
  // TODO: read PRAGMA user_version, execAsync each pending migration in a
  // transaction, then write the new version back with PRAGMA user_version = N.
  // Enable WAL once, on version 0 only.
  throw new Error("TODO: implement migrateDbIfNeeded()");
}