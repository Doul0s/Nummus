import type { SQLiteDatabase } from "expo-sqlite";

import type { IsoDate } from "@/lib/date";

export type Expense = {
  id: number;
  /** Integer minor units (e.g. cents) — never a float. */
  amountMinor: number;
  currencyCode: string;
  label: string;
  note: string | null;
  /** ISO 8601 calendar date, YYYY-MM-DD. */
  spentAt: IsoDate;
  /** ISO 8601 timestamp, set by SQLite. */
  createdAt: string;
};

export type NewExpense = {
  amountMinor: number;
  currencyCode: string;
  label: string;
  note?: string | null;
  spentAt: IsoDate;
};

export type ExpensePatch = Partial<Omit<Expense, "id" | "createdAt">>;

/** Half-open range on spent_at: startIso inclusive, endIso exclusive. */
export type DateRange = { startIso: IsoDate; endIso: IsoDate };

/** TODO: SELECT ... ORDER BY spent_at DESC, id DESC, binding the range params. */
export async function listExpenses(
  db: SQLiteDatabase,
  range?: DateRange
): Promise<Expense[]> {
  throw new Error("TODO: implement listExpenses()");
}

export async function getExpense(db: SQLiteDatabase, id: number): Promise<Expense | null> {
  throw new Error("TODO: implement getExpense()");
}

/** TODO: INSERT ... RETURNING lastInsertRowId, or return it from runAsync. */
export async function insertExpense(db: SQLiteDatabase, input: NewExpense): Promise<number> {
  throw new Error("TODO: implement insertExpense()");
}

export async function updateExpense(
  db: SQLiteDatabase,
  id: number,
  patch: ExpensePatch
): Promise<void> {
  throw new Error("TODO: implement updateExpense()");
}

export async function deleteExpense(db: SQLiteDatabase, id: number): Promise<void> {
  throw new Error("TODO: implement deleteExpense()");
}

/** Sum of amount_minor over the range. Mixing currencies is the caller's problem. */
export async function sumExpensesMinor(
  db: SQLiteDatabase,
  range?: DateRange
): Promise<number> {
  throw new Error("TODO: implement sumExpensesMinor()");
}